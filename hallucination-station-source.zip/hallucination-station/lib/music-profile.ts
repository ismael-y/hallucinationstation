// Original music: a suspenseful intro, then an arcade pulse that ramps up.
export function musicProfile(phase?:string,remaining=Infinity){
 const active=phase==='write'||phase==='vote';
 const intensity=active?Math.max(0,Math.min(1,(15-remaining)/15)):0;
 return {intro:phase==='countdown',active,intensity,bpm:phase==='countdown'?120:active?112+intensity*56:104};
}
