CREATE TABLE `question_history` (
	`id` text PRIMARY KEY NOT NULL,
	`used` text DEFAULT '[]' NOT NULL,
	`version` integer DEFAULT 0 NOT NULL
);
