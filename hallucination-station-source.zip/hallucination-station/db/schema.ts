import { integer, sqliteTable, text } from 'drizzle-orm/sqlite-core';
export const rooms = sqliteTable('rooms', {code:text('code').primaryKey(), state:text('state').notNull(), version:integer('version').notNull().default(0), expires:integer('expires').notNull()});
export const questionHistory = sqliteTable('question_history', {id:text('id').primaryKey(),used:text('used').notNull().default('[]'),version:integer('version').notNull().default(0)});
