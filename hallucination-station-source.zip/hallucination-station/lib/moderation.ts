// Enforced by the API for every new nickname and bluff. Keep whole-word
// boundaries so innocent words such as "class" and "assistance" stay usable.
const blocked = [
 'fuck(?:er|ers|ing|ed|s)?', 'motherfuck(?:er|ers|ing)?',
 'shit(?:s|ty|ting|ted|head|heads)?', 'bullshit', 'bitch(?:es|y|ing)?',
 'asshole(?:s)?', 'bastard(?:s)?', 'cunt(?:s)?', 'cock(?:s|sucker|suckers)?',
 'dick(?:s|head|heads)?', 'pussy', 'pussies', 'whore(?:s)?', 'slut(?:s)?',
 'nigger(?:s)?', 'nigga(?:s)?', 'faggot(?:s)?', 'fag(?:s)?',
 'retard(?:s|ed)?', 'kike(?:s)?', 'chink(?:s)?', 'tranny', 'trannies',
 'spic(?:s)?', 'wetback(?:s)?', 'coon(?:s)?',
];
const ordinary = new RegExp(`(?:^|[^a-z0-9])(?:${blocked.join('|')})(?=$|[^a-z0-9])`, 'i');
// For disguised words, separators may occur between letters, but matching
// still requires a word boundary on either side. Apply only to unambiguous roots.
const roots = ['fuck','shit','bitch','asshole','cunt','cocksucker','dickhead','nigger','nigga','faggot','kike','wetback'];
const disguised = new RegExp(`(?:^|[^a-z0-9])(?:${roots.map(w=>w.split('').join('[^a-z0-9]*')).join('|')})(?:s|er|ers|ing|ed)?(?=$|[^a-z0-9])`, 'i');
export function hasBlockedLanguage(input: string): boolean {
 const plain=input.normalize('NFKD').replace(/\p{M}/gu,'').replace(/[\u200B-\u200F\u202A-\u202E\u2060-\u206F\uFEFF]/g,'').toLowerCase();
 const folded=plain.replace(/[@4]/g,'a').replace(/3/g,'e').replace(/[1!]/g,'i').replace(/0/g,'o').replace(/[5$]/g,'s').replace(/7/g,'t');
 return ordinary.test(plain)||ordinary.test(folded)||disguised.test(folded)
  || /\b(?:kill yourself|kill all (?:jews|muslims|blacks|gays)|heil hitler)\b/.test(folded);
}
