'use client';
import { useEffect, useRef, useState } from 'react';
import { musicProfile } from '@/lib/music-profile';
import { Volume2, VolumeX } from 'lucide-react';

// Original 16-bar arcade arrangement, synthesized locally without downloads.
export function Music({phase,deadline=0,serverOffset=0}:{phase?:string;deadline?:number;serverOffset?:number}={}){
 const scene=useRef({phase,deadline,serverOffset});scene.current={phase,deadline,serverOffset};
 const [playing,setPlaying]=useState(false),[failed,setFailed]=useState(false);
 const audio=useRef<AudioContext|null>(null),timer=useRef<ReturnType<typeof setInterval>|null>(null),master=useRef<GainNode|null>(null);
 const stop=()=>{if(timer.current)clearInterval(timer.current);timer.current=null;const ctx=audio.current;audio.current=null;master.current=null;if(ctx)void ctx.close().catch(()=>{});setPlaying(false)};
 useEffect(()=>()=>{if(timer.current)clearInterval(timer.current);if(audio.current)void audio.current.close().catch(()=>{})},[]);
 async function toggle(){if(audio.current){stop();return}setFailed(false);
 try{const Audio=(window as any).AudioContext||(window as any).webkitAudioContext;if(!Audio)throw Error('Audio unsupported');const ctx:AudioContext=new Audio();audio.current=ctx;await ctx.resume();if(audio.current!==ctx)return;const gain=ctx.createGain();gain.gain.value=.16;gain.connect(ctx.destination);master.current=gain;
 const note=(midi:number,time:number,duration:number,volume:number,type:OscillatorType='triangle')=>{const osc=ctx.createOscillator(),amp=ctx.createGain();osc.type=type;osc.frequency.value=440*2**((midi-69)/12);amp.gain.setValueAtTime(0,time);amp.gain.linearRampToValueAtTime(volume,time+.015);amp.gain.exponentialRampToValueAtTime(.001,time+duration);osc.connect(amp);amp.connect(gain);osc.start(time);osc.stop(time+duration+.02);osc.onended=()=>{osc.disconnect();amp.disconnect()}};
 const roots=[45,41,48,43];const pattern=[0,7,12,7,3,7,15,12,0,7,12,19,15,12,7,3];let step=0,next=ctx.currentTime+.06,lastPhase=scene.current.phase,lastCountdown=-1;
 function schedule(){if(ctx.state!=='running'){next=ctx.currentTime+.05;return}const state=scene.current;const remaining=(state.deadline-Date.now()-state.serverOffset)/1000;const mood=musicProfile(state.phase,remaining);
 if(lastPhase!==state.phase){lastPhase=state.phase;step=0;next=ctx.currentTime+.02;lastCountdown=-1}
 if(next<ctx.currentTime)next=ctx.currentTime+.02;
 if(mood.intro){const count=Math.ceil(remaining);if(count!==lastCountdown&&count>0){lastCountdown=count;const t=ctx.currentTime+.01;note(count>1?33:45,t,.75,.3,'sine');note(count>1?45:57,t,.7,.15);if(count<=1){note(60,t,.8,.1);note(64,t,.8,.08)}}}
 while(next<ctx.currentTime+.12){const bar=Math.floor(step/8),root=mood.intro?33:roots[Math.floor(bar/4)%4];
 if(mood.intro){note(root+7+(step%2?12:0),next,.18,.11,'triangle')}
 else{note(root+12+pattern[step%16],next,.23-.08*mood.intensity,.14);if(step%2===0)note(root,next,.4,.20,'sine');if(step%8===0){note(root+12,next,mood.active?.5:1.1,.07,'sine');note(root+19,next,mood.active?.5:1.1,.055,'sine')}
 if(mood.intensity>0){note(81+(step%2)*7,next,.045,.045+mood.intensity*.065,'square');if(step%2===1&&mood.intensity>.6)note(root,next,.12,.16,'triangle')}}
 step=(step+1)%128;next+=60/mood.bpm/2}}

 schedule();timer.current=setInterval(schedule,50);setPlaying(true);
 }catch{stop();setFailed(true)}}
 return <button type="button" className="music-button" aria-label={playing?'Mute background music':'Play background music on this device'} aria-pressed={playing} title={failed?'Audio unavailable on this device. Tap to retry.':'Music plays only on your device'} onClick={()=>void toggle()}>{playing?<Volume2 size={18}/>:<VolumeX size={18}/>}<span>{failed?'Retry music':playing?'Music on':'Music off'}</span></button>
}
