export const TOTAL_ROUNDS = 5;
import { initialFacts } from './initial-facts';
import additionalFacts from './question-bank.json';
export const facts = [...initialFacts.map((f,i)=>({...f,category:i===5?'General knowledge':[0,2,3].includes(i)?'Nature':'Space'})),...additionalFacts];
export type Player={id:string;token:string;name:string;score:number;callUsed?:boolean};
export type Option={id:string;text:string;owners:string[];real:boolean};
export type Room={calls?:Record<string,string>;callGains?:Record<string,number>;historyId?:string;seen?:number[];code:string;host:string;players:Player[];phase:'lobby'|'countdown'|'write'|'vote'|'reveal'|'finished';round:number;deck:number[];deadline:number;bluffs:Record<string,string>;votes:Record<string,string>;options:Option[];gains:Record<string,number>};
export function shuffle<T>(a:T[]):T[]{const result=[...a];for(let i=result.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[result[i],result[j]]=[result[j],result[i]]}return result}
export function begin(r:Room){r.calls={};r.callGains={};r.phase='write';r.deadline=Date.now()+45000;r.bluffs={};r.votes={};r.options=[];r.gains={}}
export function advance(r:Room){
 if(r.phase==='countdown'&&Date.now()>=r.deadline)begin(r);
 if(r.phase==='write'&&(Date.now()>=r.deadline||r.players.every(p=>r.bluffs[p.id]))){
 const options:Option[]=[{id:crypto.randomUUID(),text:facts[r.deck[r.round-1]].a,owners:[],real:true}];
 for(const [owner,text] of Object.entries(r.bluffs)){const existing=options.find(o=>normalize(o.text)===normalize(text));if(existing)existing.owners.push(owner);else options.push({id:crypto.randomUUID(),text,owners:[owner],real:false})}
 r.options=shuffle(options);r.phase='vote';r.deadline=Date.now()+30000;
 }
 if(r.phase==='vote'&&(Date.now()>=r.deadline||r.players.every(p=>r.votes[p.id]))){r.gains=Object.fromEntries(r.players.map(p=>[p.id,0]));for(const [voter,id] of Object.entries(r.votes)){const o=r.options.find(o=>o.id===id);if(!o)continue;if(o.real)r.gains[voter]+=2;else o.owners.forEach(owner=>r.gains[owner]++);}r.callGains={};for(const [caller,id] of Object.entries(r.calls??{})){const o=r.options.find(o=>o.id===id);if(o){const bonus=o.real?-1:1;r.callGains[caller]=bonus;r.gains[caller]+=bonus}}r.players.forEach(p=>p.score+=r.gains[p.id]);r.phase='reveal';r.deadline=0;}
}
export function normalize(s:string){return s.toLowerCase().replace(/[^a-z0-9]/g,'')}
export function view(r:Room,token:string){const me=r.players.find(p=>p.token===token);if(!me)throw new Error('Rejoin this room from your original device.');const fact=r.round?facts[r.deck[r.round-1]]:null;const reveal=['reveal','finished'].includes(r.phase);return {...r,historyId:undefined,seen:undefined,totalRounds:r.deck.length||TOTAL_ROUNDS,deck:undefined,players:r.players.map(({token,...p})=>({...p,callUsed:undefined,submitted:!!r.bluffs[p.id],voted:!!r.votes[p.id]})),calls:reveal?r.calls:undefined,callGains:reveal?r.callGains:undefined,callAvailable:!me.callUsed,myCall:r.calls?.[me.id],bluffs:undefined,votes:reveal?r.votes:undefined,me:me.id,isHost:me.id===r.host,myBluff:r.bluffs[me.id],myVote:r.votes[me.id],question:r.phase==='countdown'?undefined:fact?.q,fact:reveal?fact:undefined,options:r.options.map(o=>reveal?o:{id:o.id,text:o.text,mine:o.owners.includes(me.id)&&!o.real}),serverNow:Date.now()}}

export function drawDeck(previous:number[]=[]){
 let used=[...new Set(previous.filter(i=>Number.isInteger(i)&&i>=0&&i<facts.length))];
 let available=shuffle(facts.map((_,i)=>i).filter(i=>!used.includes(i)));
 const deck:number[]=[];const categories=new Set<string>();
 while(deck.length<TOTAL_ROUNDS){
  if(!available.length){used=[];available=shuffle(facts.map((_,i)=>i).filter(i=>!deck.includes(i)))}
  let position=available.findIndex(i=>!categories.has(facts[i].category));if(position<0)position=0;
  const [index]=available.splice(position,1);deck.push(index);used.push(index);categories.add(facts[index].category);
 }
 return {deck,used};
}
